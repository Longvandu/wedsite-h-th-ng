<?php

require_once "config/database.php";

$sql = "SELECT * FROM exercises
        WHERE trang_thai = 1
        ORDER BY id DESC";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="vi">

<head>

    <meta charset="UTF-8">

    <title>Bài tập - Hệ thống bài tập</title>

    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<?php include "includes/header.php"; ?>


<main class="exercise-page">

    <div class="exercise-container">

        <div class="exercise-page-title">

            <h1>Danh sách bài tập</h1>

            <p>
                Các bài tập dành cho học sinh lớp 10
            </p>

        </div>


        <div class="exercise-table-box">

            <table class="student-exercise-table">

                <thead>

                    <tr>

                        <th>Mã</th>

                        <th>Tên bài tập</th>

                        <th>Mô tả</th>

                        <th>Nền tảng</th>

                        <th>Thao tác</th>

                    </tr>

                </thead>

                <tbody>

                <?php if ($result->num_rows > 0): ?>

                    <?php while ($row = $result->fetch_assoc()): ?>

                        <tr>

                            <td>
                                <?php echo $row["id"]; ?>
                            </td>

                            <td class="exercise-name">

                                <?php echo htmlspecialchars($row["ten_bai"]); ?>

                            </td>

                            <td>

                                <?php echo htmlspecialchars($row["mo_ta"]); ?>

                            </td>

                            <td>

                                <?php echo htmlspecialchars($row["nen_tang"]); ?>

                            </td>

                            <td>

                                <a
                                    href="<?php echo htmlspecialchars($row["link"]); ?>"
                                    target="_blank"
                                    class="btn-do-exercise"
                                >
                                    Làm bài
                                </a>

                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="5" class="empty-message">

                            Chưa có bài tập nào.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</main>


<?php include "includes/footer.php"; ?>


</body>

</html>