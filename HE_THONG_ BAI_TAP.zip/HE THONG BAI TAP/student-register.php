<?php

session_start();

require_once "config/database.php";

if (isset($_POST["register"])) {

    $username = $_POST["username"];
    $password = $_POST["password"];
    $password_confirm = $_POST["password_confirm"];

    if ($password != $password_confirm) {

        $error = "Mật khẩu nhập lại không khớp!";

    } else {

        $sql = "SELECT * FROM users WHERE username = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows > 0) {

            $error = "Tên tài khoản đã tồn tại!";

        } else {

            $sql = "INSERT INTO users (username, password, role)
                    VALUES (?, ?, 'student')";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $username, $password);

            if ($stmt->execute()) {

                header("Location: student-login.php");
                exit();

            } else {

                $error = "Đăng ký thất bại!";

            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="vi">

<head>

    <meta charset="UTF-8">

    <title>Đăng ký học sinh</title>

    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<div class="login-container">

    <div class="login-box">

        <h1>ĐĂNG KÝ</h1>

        <p class="login-title">
            Tạo tài khoản học sinh
        </p>

        <?php

        if (isset($error)) {

            echo '<p class="error">' . $error . '</p>';

        }

        ?>

        <form method="POST">

            <div class="form-group">

                <label>Tên tài khoản</label>

                <input
                    type="text"
                    name="username"
                    placeholder="Nhập tên tài khoản"
                    required
                >

            </div>


            <div class="form-group">

                <label>Mật khẩu</label>

                <input
                    type="password"
                    name="password"
                    placeholder="Nhập mật khẩu"
                    required
                >

            </div>


            <div class="form-group">

                <label>Nhập lại mật khẩu</label>

                <input
                    type="password"
                    name="password_confirm"
                    placeholder="Nhập lại mật khẩu"
                    required
                >

            </div>


            <button type="submit" name="register">
                Đăng ký
            </button>

        </form>


        <p style="text-align:center; margin-top:20px;">

            Đã có tài khoản?

            <a href="student-login.php">
                Đăng nhập
            </a>

        </p>

    </div>

</div>

</body>

</html>