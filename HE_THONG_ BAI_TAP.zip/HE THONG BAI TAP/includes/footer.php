<footer class="main-footer">

    <div class="footer-container">

        <div class="footer-info">

            <h3>📚 Hệ thống bài tập</h3>

            <p>
                Hệ thống lưu trữ và quản lý các bài tập trực tuyến
                dành cho học sinh.
            </p>

        </div>


        <div class="footer-copy">

            <p>
                © 2026 Hệ thống bài tập. All rights reserved.
            </p>

        </div>

    </div>

</footer>