<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>

<header class="main-header">

    <div class="header-container">

        <div class="logo">
            📚 Hệ thống bài tập
        </div>

        <nav class="main-nav">

            <a href="index.php">
                Trang chủ
            </a>

            <a href="bai-tap.php">
                Bài tập
            </a>

            <?php if (isset($_SESSION["student"])): ?>

                <a href="#" >
                    👤 <?php echo $_SESSION["student"]; ?>
                </a>

                <a href="student-logout.php" class="logout-link">
                    Đăng xuất
                </a>

            <?php else: ?>

                <a href="student-login.php">
                    Đăng nhập
                </a>

            <?php endif; ?>

        </nav>

    </div>

</header>