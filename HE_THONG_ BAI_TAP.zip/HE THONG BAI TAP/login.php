<?php

session_start();

require_once "config/database.php";

if (isset($_POST["login"])) {

    $username = $_POST["username"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM users
            WHERE username = ?
            AND password = ?
            AND role = 'admin'";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "ss",
        $username,
        $password
    );

    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows == 1) {

        $_SESSION["admin"] = $username;

        header("Location: admin/dashboard.php");
        exit();

    } else {

        $error = "Sai tài khoản hoặc mật khẩu!";

    }
}

?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <title>Đăng nhập Admin</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

<div class="login-container">

    <div class="login-box">

        <h1>ĐĂNG NHẬP</h1>

        <p class="login-title">Hệ thống bài tập trực tuyến</p>

        <?php if (isset($error)) { ?>
            <p class="error">
                <?php echo $error; ?>
            </p>
        <?php } ?>

        <form method="POST">

            <div class="form-group">
                <label>Tài khoản</label>
                <input
                    type="text"
                    name="username"
                    placeholder="Nhập tài khoản"
                    required
                >
            </div>

            <div class="form-group">
                <label>Mật khẩu</label>
                <input
                    type="password"
                    name="password"
                    placeholder="Nhập mật khẩu"
                    required
                >
            </div>

            <button type="submit" name="login">
                ĐĂNG NHẬP
            </button>

        </form>

    </div>

</div>

</body>

</html>