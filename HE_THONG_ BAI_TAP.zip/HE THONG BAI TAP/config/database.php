<?php

$servername = "sql310.byethost15.com";
$username = "b15_43079457";
$password = "H3102006@";
$dbname = "b15_43079457_he_thong_bai_tap";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

?>