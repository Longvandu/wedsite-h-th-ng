<?php
require_once "config/database.php";

$sql = "SELECT * FROM exercises
        WHERE trang_thai = 1
        ORDER BY id DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <title>Bài tập trực tuyến</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <?php include "includes/header.php"; ?>
    <div class="student-page">

        <div class="student-container">

            <div class="student-title">
                <h1>HỆ THỐNG BÀI TẬP TRỰC TUYẾN</h1>
                <p>Kho bài tập dành cho học sinh</p>
            </div>

            <div class="exercise-section">

                <h2>Danh sách bài tập</h2>
                <div class="exercise-list">

                    <?php if ($result->num_rows > 0) { ?>

                        <?php while ($row = $result->fetch_assoc()) { ?>

                            <div class="exercise-card">

                                <h3>
                                    <?php echo $row["ten_bai"]; ?>
                                </h3>

                                <p class="exercise-description">
                                    <?php echo $row["mo_ta"]; ?>
                                </p>

                                <p class="exercise-platform">
                                    Nền tảng:
                                    <strong>
                                        <?php echo $row["nen_tang"]; ?>
                                    </strong>
                                </p>

                                <a
                                    class="btn-do-exercise"
                                    href="<?php echo $row["link"]; ?>"
                                    target="_blank">
                                    Làm bài
                                </a>

                            </div>

                        <?php } ?>

                    <?php } else { ?>

                        <div class="empty-message">
                            <p>Hiện chưa có bài tập nào.</p>
                        </div>

                    <?php } ?>

                </div>

            </div>

        </div>

    </div>
<?php include "includes/footer.php"; ?>
</body>

</html>