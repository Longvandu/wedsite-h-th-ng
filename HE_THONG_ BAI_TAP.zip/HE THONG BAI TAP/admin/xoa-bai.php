<?php

require_once "../config/database.php";
require_once "../includes/auth.php";

if (isset($_GET["id"])) {

    $id = $_GET["id"];

    $sql = "DELETE FROM exercises WHERE id = ?";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: bai-tap.php");
        exit();
    } else {
        echo "Xóa bài tập thất bại!";
    }
}

?>