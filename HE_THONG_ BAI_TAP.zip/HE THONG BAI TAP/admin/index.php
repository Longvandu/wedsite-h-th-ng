<?php

require_once "../includes/auth.php";

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản trị hệ thống</title>
</head>

<body>

    <h1>TRANG QUẢN TRỊ</h1>

    <p>Chào mừng đến với trang quản lý hệ thống bài tập.</p>

    <h2>Quản lý bài tập</h2>

    <a href="bai-tap.php">Quản lý bài tập</a>
    <br><br>

    <a href="logout.php">Đăng xuất</a>

</body>
</html>