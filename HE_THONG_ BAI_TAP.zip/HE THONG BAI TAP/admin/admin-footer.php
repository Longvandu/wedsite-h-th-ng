<footer class="admin-footer">

    <div class="admin-footer-container">

        <p>
            © 2026 Hệ thống bài tập
        </p>

        <p>
            Trang quản trị
        </p>

    </div>

</footer>