<?php

require_once "../config/database.php";
require_once "../includes/auth.php";

if (isset($_POST["them"])) {

    $ten_bai = $_POST["ten_bai"];
    $mo_ta = $_POST["mo_ta"];
    $link = $_POST["link"];
    $nen_tang = $_POST["nen_tang"];

    $sql = "INSERT INTO exercises 
            (ten_bai, mo_ta, link, nen_tang)
            VALUES (?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "ssss",
        $ten_bai,
        $mo_ta,
        $link,
        $nen_tang
    );

    if ($stmt->execute()) {
        header("Location: bai-tap.php");
        exit();
    } else {
        echo "Thêm bài tập thất bại!";
    }
}

?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <title>Thêm bài tập</title>

    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
<?php include "admin-header.php"; ?>
<div class="admin-page">

    <div class="admin-container">

        <div class="form-page">

            <div class="page-header">
                <div>
                    <h1>Thêm bài tập</h1>
                    <p>Thêm một bài tập mới vào hệ thống</p>
                </div>
            </div>


            <div class="form-box">

                <form method="POST">

                    <div class="form-group">
                        <label>Tên bài tập</label>

                        <input
                            type="text"
                            name="ten_bai"
                            placeholder="Nhập tên bài tập"
                            required
                        >
                    </div>


                    <div class="form-group">
                        <label>Mô tả</label>

                        <textarea
                            name="mo_ta"
                            placeholder="Nhập mô tả bài tập"
                            rows="5"
                        ></textarea>
                    </div>


                    <div class="form-group">
                        <label>Link bài tập</label>

                        <input
                            type="url"
                            name="link"
                            placeholder="https://..."
                            required
                        >
                    </div>


                    <div class="form-group">
                        <label>Nền tảng</label>

                        <input
                            type="text"
                            name="nen_tang"
                            placeholder="Ví dụ: Google Forms, Quizizz..."
                        >
                    </div>


                    <div class="form-actions">

                        <a href="bai-tap.php" class="btn-cancel">
                            Hủy
                        </a>

                        <button
                            type="submit"
                            name="them"
                            class="btn-primary"
                        >
                            + Thêm bài tập
                        </button>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>
<?php include "admin-footer.php"; ?>
</body>
</html>