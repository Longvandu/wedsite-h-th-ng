<?php
require_once "../includes/auth.php";
require_once "../config/database.php";

$id = $_GET["id"];

// Lấy thông tin bài tập
$sql = "SELECT * FROM exercises WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    die("Không tìm thấy bài tập!");
}

// Khi nhấn nút Sửa
if (isset($_POST["sua"])) {

    $ten_bai = $_POST["ten_bai"];
    $mo_ta = $_POST["mo_ta"];
    $link = $_POST["link"];
    $nen_tang = $_POST["nen_tang"];

    $sql = "UPDATE exercises
            SET ten_bai = ?,
                mo_ta = ?,
                link = ?,
                nen_tang = ?
            WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "ssssi",
        $ten_bai,
        $mo_ta,
        $link,
        $nen_tang,
        $id
    );

    if ($stmt->execute()) {
        header("Location: bai-tap.php");
        exit();
    } else {
        echo "Sửa bài tập thất bại!";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <title>Sửa bài tập</title>

    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
<?php include "admin-header.php"; ?>
<div class="admin-page">

    <div class="admin-container">

        <div class="form-page">

            <div class="page-header">

                <div>
                    <h1>Sửa bài tập</h1>
                    <p>Chỉnh sửa thông tin bài tập</p>
                </div>

            </div>


            <div class="form-box">

                <form method="POST">

                    <!-- Tên bài tập -->
                    <div class="form-group">

                        <label>Tên bài tập</label>

                        <input
                            type="text"
                            name="ten_bai"
                            value="<?php echo htmlspecialchars($row["ten_bai"]); ?>"
                            required
                        >

                    </div>


                    <!-- Mô tả -->
                    <div class="form-group">

                        <label>Mô tả</label>

                        <textarea
                            name="mo_ta"
                            rows="5"
                        ><?php echo htmlspecialchars($row["mo_ta"]); ?></textarea>

                    </div>


                    <!-- Link -->
                    <div class="form-group">

                        <label>Link bài tập</label>

                        <input
                            type="url"
                            name="link"
                            value="<?php echo htmlspecialchars($row["link"]); ?>"
                            required
                        >

                    </div>


                    <!-- Nền tảng -->
                    <div class="form-group">

                        <label>Nền tảng</label>

                        <input
                            type="text"
                            name="nen_tang"
                            value="<?php echo htmlspecialchars($row["nen_tang"]); ?>"
                            placeholder="Ví dụ: Google Forms, Quizizz..."
                        >

                    </div>


                    <!-- Nút -->
                    <div class="form-actions">

                        <a href="bai-tap.php" class="btn-cancel">
                            Hủy
                        </a>

                        <button
                            type="submit"
                            name="sua"
                            class="btn-primary"
                        >
                            Lưu thay đổi
                        </button>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>
<?php include "admin-footer.php"; ?>
</body>
</html>