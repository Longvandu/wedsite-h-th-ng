<?php
require_once "../includes/auth.php";
require_once "../config/database.php";

$sql_bai = "SELECT COUNT(*) AS tong FROM exercises";
$result_bai = $conn->query($sql_bai);
$row_bai = $result_bai->fetch_assoc();

$sql_user = "SELECT COUNT(*) AS tong FROM users";
$result_user = $conn->query($sql_user);
$row_user = $result_user->fetch_assoc();

$sql_lop = "SELECT COUNT(*) AS tong FROM classes";
$result_lop = $conn->query($sql_lop);
$row_lop = $result_lop->fetch_assoc();

$sql_chu_de = "SELECT COUNT(*) AS tong FROM subjects";
$result_chu_de = $conn->query($sql_chu_de);
$row_chu_de = $result_chu_de->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>

    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
<?php include "admin-header.php"; ?>
<div class="admin-page">

    <div class="admin-container">

        <div class="dashboard-title">
            <h1>Dashboard</h1>
            <p>Quản lý hệ thống bài tập trực tuyến</p>
        </div>

        <div class="dashboard-cards">

            <div class="dashboard-card">
                <div class="dashboard-icon">📚</div>

                <div>
                    <p>Tổng bài tập</p>
                    <h2><?php echo $row_bai["tong"]; ?></h2>
                </div>
            </div>


            <div class="dashboard-card">
                <div class="dashboard-icon">👨‍🎓</div>

                <div>
                    <p>Người dùng</p>
                    <h2><?php echo $row_user["tong"]; ?></h2>
                </div>
            </div>


            <div class="dashboard-card">
                <div class="dashboard-icon">🏫</div>

                <div>
                    <p>Lớp học</p>
                    <h2><?php echo $row_lop["tong"]; ?></h2>
                </div>
            </div>


            <div class="dashboard-card">
                <div class="dashboard-icon">📖</div>

                <div>
                    <p>Chủ đề</p>
                    <h2><?php echo $row_chu_de["tong"]; ?></h2>
                </div>
            </div>

        </div>


        <div class="dashboard-management">

            <h2>Quản lý hệ thống</h2>

            <div class="management-list">

                <a href="bai-tap.php" class="management-item">
                    <span>📚</span>
                    <div>
                        <strong>Quản lý bài tập</strong>
                        <p>Thêm, sửa và xóa bài tập</p>
                    </div>
                </a>


                <a href="#" class="management-item">
                    <span>🏫</span>
                    <div>
                        <strong>Quản lý lớp học</strong>
                        <p>Quản lý danh sách lớp</p>
                    </div>
                </a>


                <a href="#" class="management-item">
                    <span>📖</span>
                    <div>
                        <strong>Quản lý chủ đề</strong>
                        <p>Quản lý các chủ đề bài học</p>
                    </div>
                </a>

            </div>

        </div>


        <div class="dashboard-footer">

            <a href="../index.php">
                ← Xem trang học sinh
            </a>

            <a href="logout.php">
                Đăng xuất
            </a>

        </div>

    </div>

</div>
<?php include "admin-footer.php"; ?>
</body>
</html>