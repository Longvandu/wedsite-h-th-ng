<header class="admin-header">

    <div class="admin-header-container">

        <div class="admin-logo">
            ⚙️ Quản trị hệ thống
        </div>

        <nav class="admin-nav">

            <a href="dashboard.php">
                Dashboard
            </a>

            <a href="bai-tap.php">
                Quản lý bài tập
            </a>

            <a href="logout.php" class="admin-logout">
                Đăng xuất
            </a>

        </nav>

    </div>

</header>