<?php

require_once "../config/database.php";
require_once "../includes/auth.php";

$sql = "SELECT * FROM exercises";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <title>Quản lý bài tập</title>

    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
<?php include "admin-header.php"; ?>
<div class="admin-page">

    <div class="admin-container">

        <div class="page-header">

            <div>
                <h1>Quản lý bài tập</h1>
                <p>Quản lý danh sách bài tập trực tuyến</p>
            </div>

            <a href="them-bai.php" class="btn-primary">
                + Thêm bài tập
            </a>

        </div>


        <div class="exercise-table-box">

            <table class="exercise-table">

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tên bài tập</th>
                        <th>Mô tả</th>
                        <th>Nền tảng</th>
                        <th>Link</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>

                <tbody>

                <?php while ($row = $result->fetch_assoc()) { ?>

                    <tr>

                        <td>
                            <?php echo $row["id"]; ?>
                        </td>

                        <td>
                            <strong>
                                <?php echo $row["ten_bai"]; ?>
                            </strong>
                        </td>

                        <td>
                            <?php echo $row["mo_ta"]; ?>
                        </td>

                        <td>
                            <?php echo $row["nen_tang"]; ?>
                        </td>

                        <td>
                            <a
                                href="<?php echo $row["link"]; ?>"
                                target="_blank"
                                class="link-exercise"
                            >
                                Mở bài
                            </a>
                        </td>

                        <td>

                            <a
                                href="sua-bai.php?id=<?php echo $row["id"]; ?>"
                                class="btn-edit"
                            >
                                Sửa
                            </a>

                            <a
                                href="xoa-bai.php?id=<?php echo $row["id"]; ?>"
                                class="btn-delete"
                                onclick="return confirm('Bạn có chắc muốn xóa bài tập này không?');"
                            >
                                Xóa
                            </a>

                        </td>

                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>


        <div class="page-back">

            <a href="dashboard.php">
                ← Quay lại Dashboard
            </a>

        </div>

    </div>

</div>
<?php include "admin-footer.php"; ?>
</body>
</html>